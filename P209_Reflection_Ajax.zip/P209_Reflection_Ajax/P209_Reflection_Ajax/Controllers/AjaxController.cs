﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_Reflection_Ajax.DAL;
using P209_Reflection_Ajax.Models;

namespace P209_Reflection_Ajax.Controllers
{
    public class AjaxController : Controller
    {
        private readonly StudentContext _context;
        public AjaxController()
        {
            _context = new StudentContext();
        }
        // GET: Ajax

        public ActionResult GetStudents(int id)
        {
            var model = _context.Students.Where(s => s.GroupId == id).Select(s => new
            {
                s.Id,
                s.Name
            });

            return Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetStudentsHtml(int id)
        {
            var model = _context.Students.Where(s => s.GroupId == id);

            return PartialView("_StudentsList", model);
        }
    }
}
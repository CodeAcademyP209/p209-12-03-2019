﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_Reflection_Ajax.Extensions;
using P209_Reflection_Ajax.DAL;
using P209_Reflection_Ajax.Models;

namespace P209_Reflection_Ajax.Controllers
{
    public class HomeController : Controller
    {
        private readonly StudentContext _context;

        public HomeController()
        {
            _context = new StudentContext();
        }
        public ActionResult Index()
        {
            return View(_context.Groups);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }

    public class User
    {
        public int Id { get; set; }
        public string Fullname { get; set; }
    }
}
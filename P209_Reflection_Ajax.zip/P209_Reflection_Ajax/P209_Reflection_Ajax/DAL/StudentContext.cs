﻿using P209_Reflection_Ajax.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace P209_Reflection_Ajax.DAL
{
    public class StudentContext:DbContext
    {
        public StudentContext():base("SudentStrCon")
        {
        }

        public DbSet<Group> Groups { get; set; }
        public DbSet<Student> Students { get; set; }
    }
}
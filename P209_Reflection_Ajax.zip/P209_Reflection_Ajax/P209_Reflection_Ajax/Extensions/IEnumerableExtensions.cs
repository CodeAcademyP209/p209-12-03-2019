﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P209_Reflection_Ajax.Extensions
{
    public static class IEnumerableExtensions
    {
        public static IEnumerable<SelectListItem> ToSelectList<T>(this IEnumerable<T> list, string valueProp, string textProp) where T : class
        {
            //IEnumerable<SelectListItem> result = null;

            foreach (var item in list)
            {
                yield return new SelectListItem
                {
                    Value = typeof(T).GetProperty(valueProp)?.GetValue(item).ToString(),
                    Text = typeof(T).GetProperty(textProp)?.GetValue(item).ToString()
                };
                //result.Append(selectListItem);
            }
            
            //return result;
        }
    }
}
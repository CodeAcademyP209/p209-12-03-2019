namespace P209_Reflection_Ajax.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<P209_Reflection_Ajax.DAL.StudentContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(P209_Reflection_Ajax.DAL.StudentContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            context.Groups.AddOrUpdate(g => g.Name,
                new Models.Group { Name = "P209" },
                new Models.Group { Name = "P101" },
                new Models.Group { Name = "P201" },
                new Models.Group { Name = "P401" }
            );

            context.Students.AddOrUpdate(g => g.Email,
                new Models.Student { Name = "Samir", Surname = "Dadash-zade", Email = "samir6@code.az", GroupId = 1  },
                new Models.Student { Name = "Elsen", Surname = "Dadash-zade", Email = "samir5@code.az", GroupId = 2  },
                new Models.Student { Name = "Aynur", Surname = "Dadashli", Email = "samir4@code.az", GroupId = 2  },
                new Models.Student { Name = "Nadir", Surname = "Dadash-zade", Email = "samir3@code.az", GroupId = 1  },
                new Models.Student { Name = "Fidan", Surname = "Dadashsiz", Email = "samir2@code.az", GroupId = 3  },
                new Models.Student { Name = "Eli", Surname = "Dadash-zade", Email = "samir1@code.az", GroupId = 1 },
                new Models.Student { Name = "Veli", Surname = "Dadash-zade", Email = "samir8@code.az", GroupId = 2 },
                new Models.Student { Name = "Priveli", Surname = "Dadashli", Email = "samire@code.az", GroupId = 2 },
                new Models.Student { Name = "Defteri", Surname = "Dadash-zade", Email = "samir12@code.az", GroupId = 1 },
                new Models.Student { Name = "Elsen", Surname = "Dadashsiz", Email = "samir45@code.az", GroupId = 3 }
            );
        }
    }
}

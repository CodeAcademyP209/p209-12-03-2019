﻿using System;
using System.Linq;
using System.Web;

namespace P209_Reflection_Ajax.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }

        public int GroupId { get; set; }
        public virtual Group Group { get; set; }
    }
}
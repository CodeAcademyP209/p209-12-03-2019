﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            //Person person = new Person { Name = "samir" };

            //Person person = new Person { Id = 1, Firstname = "Samir", Email = "samir@code.az"};

            //var personProperties = typeof(Person).GetProperties();

            //foreach (var prop in personProperties)
            //{
            //    Console.WriteLine(prop.Name + " => " + prop.PropertyType + " => " + prop.GetValue(person) );
            //}

        }
    }

    class Person
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Email { get; set; }

        public string GetFullInfo()
        {
            return Firstname + " " + Email;
        }
    }
}
